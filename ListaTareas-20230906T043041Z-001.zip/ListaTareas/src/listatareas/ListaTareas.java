/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package listatareas;

/**
 *
 * @author labcca
 */
public class ListaTareas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int tarea ;
        String t1 = " Estudiar fundamentos de programacion ";
        String t2 = "Investigar metodos ";
        String t3 = " Exponer ";
        String t4 = " Crear un codigo ";
        String t5= " Resumen ";
        
           System.out.println (" mi tarea 1 es " + t1 );
           System.out.println (" mi tarea 2 es " + t2 );
           System.out.println (" mi tarea 3 es " + t3 );
        System.out.println (" mi tarea 4 es " + t4 );
        System.out.println (" mi tarea 5 es " + t5);
    }
   
}
